import numpy as np
import matplotlib.pyplot as plt

Vm = 325
f = 50
Im = 200
pf = 0.5

phi = np.arccos(pf)

t = np.linspace (0,0.04,1000)


Vi = Vm*np.sin(2*np.pi*f*t)
Ii = Im*np.sin(2*np.pi*f*t - phi)
Pi = Vi*Ii

plt.plot (t,Vi)
plt.plot (t,Ii)
plt.plot (t,Pi)
plt.grid()
plt.show()

Pi = Vi*Ii

P = np.mean(Pi)

print (P)