import numpy as np
import matplotlib.pyplot as plt

Ia = np.linspace(0, 100, 1000)

Isat = 80

phi = np.where(Ia < Isat, Ia, Isat + 0.1*(Ia - Isat))

Torque = phi * Ia

plt.plot(Ia, Torque)
plt.xlabel("Ia")
plt.ylabel("Torque")
plt.title("Torque–Current Characteristic")
plt.grid()
plt.show()
