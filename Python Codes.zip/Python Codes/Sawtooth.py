import numpy as np
import matplotlib.pyplot as plt

Vm = 10
f = 50
t = np.linspace (0,0.06,1000)

Vf = Vm*np.sin(2*np.pi*f*t)
V_2nd = 1/2*Vm*np.sin(2*2*np.pi*f*t)
V_3th = 1/3*Vm*np.sin(3*2*np.pi*f*t)
V_4th = 1/4*Vm*np.sin(4*2*np.pi*f*t)
V_5th = 1/5*Vm*np.sin(5*2*np.pi*f*t)
V_6th = 1/6*Vm*np.sin(6*2*np.pi*f*t)

V_re = Vf + V_2nd + V_3th + V_4th + V_5th + V_6th

plt.figure(figsize=(8,6))
plt.subplot(2,1,1)
plt.title('Sine Waves')
plt.plot(t,Vf)
plt.plot(t,V_2nd)
plt.plot(t,V_4th)
plt.plot(t,V_5th)
plt.plot(t,V_6th)
plt.ylabel('Amplitude')
plt.grid()
plt.tight_layout()

plt.subplot(2,1,2)
plt.title('Resultant Wave')
plt.plot(t,V_re)
plt.ylabel('Amplitude')
plt.grid()
plt.tight_layout()

plt.xlabel('Time')

plt.show()