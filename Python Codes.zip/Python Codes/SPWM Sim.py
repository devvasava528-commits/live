import numpy as np 
import matplotlib.pyplot as plt
import scipy.signal as signal 

V_ref_peak = 1
V_car_A = 1

fr = 50
fc = 1000

t = np.linspace(0,0.06,5000)

omega_f = 2*np.pi*fr
omega_c = 2*np.pi*fc

v_ref = V_ref_peak*np.sin(omega_f*t)
v_car = V_car_A*signal.sawtooth(omega_c*t,0.5)
v_ref_i = V_ref_peak*np.sin(omega_f*t - np.pi)

v_p1 = v_ref > v_car 
v_p2 = v_ref_i > v_car

spwm = v_p1 - (v_p2 - 1) - 1

plt.figure(figsize=(15,8))
plt.title('SPWM Simulation')
plt.xlabel('time(s)')
plt.ylabel('amplitude')

plt.subplot(5,1,1)
plt.plot(t,v_car, color='y')
plt.plot(t,v_ref, color='r')
plt.grid()

plt.subplot(5,1,2)
plt.plot(t,v_p1, color='b')
plt.grid()

plt.subplot(5,1,3)
plt.plot(t,v_car, color='y')
plt.plot(t,v_ref_i, color='r')
plt.grid()

plt.subplot(5,1,4)
plt.plot(t,v_p2, color='b')
plt.grid()

plt.subplot(5,1,5)
plt.plot(t,spwm, color='orange')
plt.grid()

plt.show()