import numpy as np 
import matplotlib.pyplot as plt

Vm = 325
Im = 100
f = 50 
cosphi = 0.8

phi = np.arccos(cosphi)

t = np.linspace(0,0.04,1000)

Vi = Vm*np.sin(2*np.pi*f*t)
Ii_ps = Im*np.sin(2*np.pi*f*t - phi)
Ii_d = Im*np.sin(2*np.pi*f*t) + 1/2*Im*np.sin(7*2*np.pi*f*t)

I2_rms = np.sqrt(np.mean(Ii_d**2))

Pi_1 = Vi*Ii_ps
P1 = np.mean(Pi_1)
S1 = Vm/np.sqrt(2) * Im/np.sqrt(2)

Pi_2 = Vi*Ii_d
P2 = np.mean(Pi_2)
S2 = Vm/np.sqrt(2) * I2_rms

PF_1 = P1/S1
PF_2 = P2/S2

V_zc = Vi > 0 
I1_zc = Ii_ps > 0

t11_i = np.argmax(V_zc)
t12_i = np.argmax(I1_zc)

t11 = t[t11_i]
t12 = t[t12_i]

delta_t1 = t11 - t12

phase_angle_1 = 360*(delta_t1/(1/f))

V_zc = Vi >= 0 
I2_zc = Ii_d >= 0

t21_i = np.argmax(V_zc)
t22_i = np.argmax(I2_zc)

t21 = t[t21_i]
t22 = t[t22_i]

delta_t2 = t22 - t21
phase_angle_2 = 360*(delta_t2/(1/f))

print ("--------|For Circuit 1|--------")
print ("Phase angle:",np.round(phase_angle_1,3))
print ("Power Factor angle:",np.round(np.rad2deg(np.arccos(PF_1))))
print ("PF:",np.round(PF_1,2))

print ("--------|For Circuit 2|--------")
print ("Phase angle:",np.round(phase_angle_2,3))
print ("Power Factor angle:",np.round(np.rad2deg(np.arccos(PF_2))))
print ("PF:",np.round(PF_2,2))


plt.figure(figsize=(8,5))
plt.subplot(2,1,1)
plt.plot(t,Vi)
plt.plot(t,Ii_ps)
plt.grid()

plt.subplot(2,1,2)
plt.plot(t,Pi_1)
plt.grid()
plt.show()

plt.figure(figsize=(8,5))
plt.subplot(2,1,1)
plt.plot(t,Vi)
plt.plot(t,Ii_d)
plt.grid()

plt.subplot(2,1,2)
plt.plot(t,Pi_2)
plt.grid()
plt.show()
