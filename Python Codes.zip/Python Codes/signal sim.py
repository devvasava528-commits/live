import numpy as np 
import matplotlib.pyplot as plt
import scipy.signal as signal 

V_car_A = 1

f_sw = 1000
omega = 2*np.pi*f_sw

width_1 = 1       # for rishing sawtooth
width_2 = 0       # for falling sawtooth
width_3 = 0.5     # for triangular 

t = np.linspace(0,0.005,1000)

V_car_1 = V_car_A*signal.sawtooth(omega*t,width_1)
V_car_2 = V_car_A*signal.sawtooth(omega*t,width_2)
V_car_3 = V_car_A*signal.sawtooth(omega*t,width_3)

plt.figure(figsize=(10,6))

plt.subplot(3,1,1)
plt.plot(t,V_car_1, color='r')
plt.grid()

plt.subplot(3,1,2)
plt.plot(t,V_car_2, color='g')
plt.grid()

plt.subplot(3,1,3)
plt.plot(t,V_car_3, color='b')
plt.grid()

plt.show()