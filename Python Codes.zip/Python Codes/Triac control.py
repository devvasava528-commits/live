import numpy as np
import matplotlib.pyplot as plt

Vm = 325
f = 50 

alpha_1_deg = 0
alpha_2_deg = 60
alpha_3_deg = 90

alpha_1_rad = np.deg2rad(alpha_1_deg)
alpha_2_rad = np.deg2rad(alpha_2_deg)
alpha_3_rad = np.deg2rad(alpha_3_deg)

t = np.linspace(0,0.08,1000)

omega = 2*np.pi*f

Vin = Vm*np.sin(omega*t)

phase = (2*np.pi*f*t) % (np.pi)

Vout_1 = np.where((phase >= alpha_1_rad), Vin, 0)
Vout_2 = np.where((phase >= alpha_2_rad), Vin, 0)
Vout_3 = np.where((phase >= alpha_3_rad), Vin, 0)

plt.figure(figsize=(10,6))

plt.subplot(4,1,1)
plt.title('Input')
plt.plot(t,Vin, color='r')
plt.ylabel('Voltage')
plt.grid()

plt.subplot(4,1,2)
plt.title('Output with Firing Angle 0°')
plt.plot(t,Vout_1, color='b')
plt.ylabel('Voltage')
plt.grid()

plt.subplot(4,1,3)
plt.title('Output with Firing Angle 60°')
plt.plot(t ,Vout_2, color='darkgreen')
plt.ylabel('Voltage')
plt.grid()

plt.subplot(4,1,4)
plt.title('Output with Firing Angle 90°')
plt.plot(t,Vout_3, color='darkorange')
plt.ylabel('Voltage')
plt.grid()

plt.tight_layout()
plt.show()

