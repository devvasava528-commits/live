import numpy as np
import matplotlib.pyplot as plt
import scipy.signal as signal

f = 50
t = np.linspace(0,1,10000)

V_fu = np.sin(2*np.pi*f*t)
V_sq = signal.square(2*np.pi*f*t)
V_st = signal.sawtooth(2*np.pi*f*t,0)

V_fu_fd = np.fft.fft(V_fu)
V_sq_fd = np.fft.fft(V_sq)
V_st_fd = np.fft.fft(V_st)

V_fu_fd_pol = np.sqrt(np.square(np.real(V_fu_fd))+np.square(np.imag(V_fu_fd)))
V_sq_fd_pol = np.sqrt(np.square(np.real(V_sq_fd))+np.square(np.imag(V_sq_fd)))
V_st_fd_pol = np.sqrt(np.square(np.real(V_st_fd))+np.square(np.imag(V_st_fd)))

plt.figure(figsize=(10,7))

plt.subplot(3,2,1)
plt.title('Time Domain')
plt.plot(t,V_fu, 'b')
plt.ylabel('Amplitude')
plt.xlabel('Time(s)')
plt.xlim(0,0.06)
plt.grid()

plt.subplot(3,2,2)
plt.title('Frequency Domain')
plt.ylabel('Amplitude')
plt.xlabel('Frequency (Hz)')
plt.plot(V_fu_fd_pol,'r')
plt.xlim(0,1000)
plt.grid()

plt.subplot(3,2,3)
plt.plot(t,V_sq, 'b')
plt.ylabel('Amplitude')
plt.xlabel('Time(s)')
plt.xlim(0,0.06)
plt.grid()

plt.subplot(3,2,4)
plt.ylabel('Amplitude')
plt.xlabel('Frequency (Hz)')
plt.plot(V_sq_fd_pol,'r')
plt.xlim(0,1000)
plt.grid()

plt.subplot(3,2,5)
plt.plot(t,V_st, 'b')
plt.ylabel('Amplitude')
plt.xlabel('Time(s)')
plt.xlim(0,0.06)
plt.grid()

plt.subplot(3,2,6)
plt.ylabel('Amplitude')
plt.xlabel('Frequency (Hz)')
plt.plot(V_st_fd_pol,'r')
plt.xlim(0,1000)
plt.grid()

plt.tight_layout()
plt.show()