import numpy as np
import matplotlib.pyplot as plt

Vm = 325
f = 50

theta_1 = 0
theta_2 = -2*np.pi/3
theta_3 = 2*np.pi/3 

omega = 2*np.pi*f

t = np.linspace(0,0.04,1000)

Vr = Vm*np.sin(omega*t + theta_1)
Vy = Vm*np.sin(omega*t + theta_2)
Vb = Vm*np.sin(omega*t + theta_3)

Vr_complex = Vm*np.exp(1j*theta_1)
Vy_complex = Vm*np.exp(1j*theta_2)
Vb_complex = Vm*np.exp(1j*theta_3)

print (Vr_complex)
print (Vy_complex)
print (Vb_complex)

Vr_real = np.real(Vr_complex)
Vr_imag = np.imag(Vr_complex)

Vy_real = np.real(Vy_complex)
Vy_imag = np.imag(Vy_complex)

Vb_real = np.real(Vb_complex)
Vb_imag = np.imag(Vb_complex)

plt.figure(figsize=(8,5))
plt.title('3 Phase Waveforms')
plt.xlabel('Time(s)')
plt.ylabel('Amplitude')
plt.plot(t,Vr, color='r', label='R Phase')
plt.plot(t,Vy, color='y', label='Y Phase')
plt.plot(t,Vb, color='b', label='B Phase')
plt.legend()
plt.grid()
plt.show()

plt.figure(figsize=(6,6))
plt.title('Phasors')
plt.xlim(-350,350)
plt.ylim(-350,350)
plt.quiver(0,0,Vr_imag,Vr_real, angles='xy', scale_units='xy', scale=1, color='r', label='R Phase')
plt.quiver(0,0,Vy_imag,Vy_real, angles='xy', scale_units='xy', scale=1, color='y', label='Y Phase')
plt.quiver(0,0,Vb_imag,Vb_real, angles='xy', scale_units='xy', scale=1, color='b', label='B Phase')
plt.legend()
plt.grid()
plt.show()

