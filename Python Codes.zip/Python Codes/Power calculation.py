import numpy as np
import matplotlib.pyplot as plt

V = 230
I = 2
pf = 0.85
phi = np.arccos(pf)

S = V * I
P = V * I * pf
Q = V * I * np.sin(phi)

plt.figure()
plt.plot([0, P], [0, 0])
plt.plot([P, P], [0, Q])
plt.plot([0, P], [0, Q])
plt.title('Power Triangle')
plt.grid()

plt.show()