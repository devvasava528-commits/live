import numpy as np
import matplotlib.pyplot as plt

Vm = 325
f = 50 

t = np.linspace (0, 0.04, 1000)

Vf = Vm*np.sin(2*np.pi*f*t)

V_3rd = 1/3*Vm*np.sin(3*2*np.pi*f*t)
V_5th = 1/5*Vm*np.sin(5*2*np.pi*f*t)
V_7th = 1/7*Vm*np.sin(7*2*np.pi*f*t)

Vr = Vf+V_3rd+V_5th+V_7th

plt.figure (figsize=(12,6))

plt.subplot (4,1,1)
plt.plot (t,Vf)
plt.grid ()

plt.subplot(4,1,2)
plt.plot (t,V_3rd)
plt.grid()

plt.subplot(4,1,3)
plt.plot(t,V_5th)
plt.grid()

plt.subplot(4,1,4)
plt.plot(t,V_7th)
plt.grid()

plt.show()

plt.subplot (2,1,1)
plt.plot (t,Vf)
plt.plot (t,V_3rd)
plt.plot (t,V_5th)
plt.plot (t,V_7th)
plt.grid()

plt.subplot (2,1,2)
plt.plot (t,Vr)
plt.grid()

plt.show()
