import numpy as np
import matplotlib.pyplot as plt

Vm = 325
Im = 150
f = 50 
cosphi = 1

phi = np.arccos(cosphi)

t = np.linspace (0,0.04,1000)

Vi = Vm*np.sin(2*np.pi*f*t) # fundamental voltage waveform 
Ii = Im*np.sin(2*np.pi*f*t - phi) # fundamental current waveform

I_7th = 0.5*Im*np.sin(7*2*np.pi*f*t) # 50 percent 7th order harmonic

Ir = Ii + I_7th

Ir_root = Ir*Ir # RMS current calculation 
Ir_mean = np.mean(Ir_root)
Ir_RMS = np.sqrt(Ir_mean)

Pi = Vi*Ir
P = np.mean (Pi)
S = Vm/np.sqrt(2)*Ir_RMS

PF = P/S

PF_angle = np.arccos(PF)

Q = Vm/np.sqrt(2)*Ir_RMS*np.sin(PF_angle)

plt.subplot (2,1,1)
plt.plot (t,Vi)
plt.plot (t,Ir)
plt.grid()

plt.subplot(2,1,2)
plt.plot(t,Pi)
plt.grid()

plt.show()

print ("Irms:",round(Ir_RMS,2),"A")
print ("P:",round(P,2),"W")
print ("Q:",round(Q,2),"VAr")
print ("S:",round(S,2),"VA")
print ("PF",round(PF,4))